import os
import sys
import braintrust
from dotenv import load_dotenv

# Add the project root to the Python search path to resolve module imports.
current_dir = os.path.dirname(os.path.abspath(__file__))
project_root = os.path.join(current_dir, "../../")
sys.path.insert(0, project_root)

# 加載環境變數
load_dotenv()

# 設定專案名稱
project_name = "iCook-RAG-Evaluation"

# 初始化 Braintrust（會自動從環境變數讀取 API Token）
braintrust.init(project=project_name)

# Import the agent creation function.
try:
    from scripts.CLI_run.agent_cli import create_agent

    AGENT_AVAILABLE = True
except ImportError as e:
    print(f"警告：無法導入代理模組: {e}")
    print("將使用模擬回應進行測試")
    AGENT_AVAILABLE = False


# 定義自訂的問答評估器
def custom_qa_evaluator(output, expected=None, input=None):
    """
    評估代理回應的品質
    """
    if expected is None:
        return braintrust.Score(
            name="qa_quality", score=0.5, metadata={"reason": "沒有預期答案進行比較"}
        )

    output_lower = str(output).lower()
    expected_lower = str(expected).lower()
    input_lower = str(input).lower() if input else ""

    # 檢查特定關鍵詞匹配
    if "素食" in expected_lower and "素食" in output_lower:
        return braintrust.Score(
            name="qa_quality", score=1.0, metadata={"reason": "正確識別素食需求"}
        )
    elif "麻婆豆腐" in expected_lower and "麻婆豆腐" in output_lower:
        return braintrust.Score(
            name="qa_quality", score=1.0, metadata={"reason": "正確回應麻婆豆腐查詢"}
        )
    elif (
        "豬肉" in input_lower
        and "高麗菜" in input_lower
        and any(dish in output_lower for dish in ["炒高麗菜", "豬肉片", "高麗菜飯"])
    ):
        return braintrust.Score(
            name="qa_quality",
            score=1.0,
            metadata={"reason": "正確使用提供的食材推薦料理"},
        )
    elif "花生過敏" in input_lower and "花生" not in output_lower:
        return braintrust.Score(
            name="qa_quality", score=1.0, metadata={"reason": "正確避免過敏原"}
        )
    elif "雞蛋" in input_lower and "豆腐" in input_lower and "花椰菜" in input_lower:
        if any(dish in output_lower for dish in ["花椰菜炒蛋", "豆腐", "蔬菜"]):
            return braintrust.Score(
                name="qa_quality", score=1.0, metadata={"reason": "正確使用素食食材"}
            )

    # 檢查是否包含基本烹飪相關內容
    cooking_keywords = ["食譜", "製作", "步驟", "配料", "料理", "烹煮", "食材"]
    if any(keyword in output_lower for keyword in cooking_keywords):
        return braintrust.Score(
            name="qa_quality", score=0.8, metadata={"reason": "包含相關烹飪內容"}
        )

    # 檢查是否有錯誤訊息
    if "錯誤" in output_lower or "error" in output_lower:
        return braintrust.Score(
            name="qa_quality", score=0.1, metadata={"reason": "系統錯誤"}
        )

    return braintrust.Score(
        name="qa_quality", score=0.2, metadata={"reason": "回應與預期不符"}
    )


# 定義測試案例（基於 few_shot_examples.txt）
test_cases = [
    {
        "input": "請給我一個不含肉類的食譜",
        "expected": "找到的食譜應為素食，例如「香菇高麗菜飯」。",
        "metadata": {"test_case_id": "001", "category": "dietary_restriction"},
    },
    {
        "input": "如何製作麻婆豆腐？",
        "expected": "應包含麻婆豆腐的製作步驟和配料。",
        "metadata": {"test_case_id": "002", "category": "specific_recipe"},
    },
    {
        "input": "我有豬肉、高麗菜和白米飯，可以做什麼料理？",
        "expected": "應推薦炒高麗菜肉絲、豬肉片蓋飯或高麗菜飯等料理。",
        "metadata": {"test_case_id": "003", "category": "ingredient_based"},
    },
    {
        "input": "我想找一個素食的食譜，我有雞蛋、豆腐和花椰菜。",
        "expected": "應推薦花椰菜炒蛋、涼拌豆腐花椰菜或蔬菜豆腐煲等素食料理。",
        "metadata": {"test_case_id": "004", "category": "vegetarian_with_ingredients"},
    },
    {
        "input": "我對花生過敏，想找一個不含花生的家常菜。",
        "expected": "應推薦不含花生的料理，如番茄炒蛋、蒜蓉蒸蝦或三杯雞。",
        "metadata": {"test_case_id": "005", "category": "allergy_restriction"},
    },
]


# 定義代理任務
def run_agent_task(input_data):
    """
    執行代理任務並記錄 prompt 到 Braintrust
    """
    # 開始一個新的 span 來記錄這次執行
    with braintrust.start_span(name="agent_task") as span:
        try:
            # 記錄輸入
            span.log(input=input_data)

            if AGENT_AVAILABLE:
                # 使用真實的代理
                agent = create_agent()

                # 記錄 prompt 相關資訊
                span.log(
                    metadata={
                        "agent_type": "iCook_RAG_Agent",
                        "model_used": os.getenv("OLLAMA_MODEL", "unknown"),
                        "use_openai": os.getenv("USE_OPENAI", "false"),
                    }
                )

                # 執行代理並獲取回應
                response = agent.invoke({"input": input_data})
                output = response.get("output", str(response))

                # 記錄輸出
                span.log(output=output)

                return output
            else:
                # 使用模擬回應
                mock_response = f"模擬回應：針對「{input_data}」的食譜建議"
                span.log(output=mock_response)
                span.log(metadata={"mode": "mock"})
                return mock_response

        except Exception as e:
            # 記錄錯誤
            span.log(error=str(e))
            span.log(metadata={"error_type": type(e).__name__})
            return f"錯誤：{str(e)}"


# 執行評估
braintrust.Eval(
    name="Agent Evaluation Run",
    data=test_cases,
    task=run_agent_task,
    scores=[custom_qa_evaluator],
)

print("評估任務已完成，請前往 Braintrust 儀表板查看結果。")
